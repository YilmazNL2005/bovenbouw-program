﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pokemon
{
    public class pikachu
    {
        public string name { get; set; }
        public int hp { get; set; }
        public string type { get; set; }
        public pikachu(string name, int hp, string type)
        {
         this.name = name;
         this.hp = hp;
         this.type = type;
        }

        public void geeftles()
        {
            Console.WriteLine(this.name);
            Console.WriteLine("Blah Blah Blah...");
        }
           
    }
}
